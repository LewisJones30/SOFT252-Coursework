/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

/**
 *
 * @author ljones30
 */
public interface IUsers {
    String setName(String name);
    String setSurname(String surname);
    String setAddress(String address);
    String setUserID (String UserID);
}
